package aly.kafka.msgsource;

// marker interface ??
public interface ISourceMsg
{

}
