package aly.kafka.test;

public class Ping
{
	public static void main(String[] args)
	{
		System.out.println("ping-ping");
	}
}
